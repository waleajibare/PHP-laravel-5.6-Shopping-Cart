<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests;
use DB;
use Session;
use Illuminate\Support\Facades\Redirect;
session_start();

class ManufacturerController extends Controller
{
    public function index()
    {

    	return view('admin.add_manufacturer');
    }


    public function save_manufacturer(Request $request)

   {

       $data=array();
             $data['manufacture_id']= $request->manufacture_id;
             $data['manufacture_name']= $request->manufacture_name;
             $data['manufacture_description']= $request->manufacture_description;
             $data['publication_status']= $request->publication_status;

             DB::table('manufacture')->insert($data);
             Session::put('message', 'Manufacturer added successfully');
             return Redirect::to('/add-manufacturer');
   	 
   }


   public function all_manufacturer()

   {
      $all_manufacturer_info = DB::table('manufacture')->get();
   	      $manage_manufacturer = view('admin.all_manufacturer')
   	          ->with('all_manufacturer_info', $all_manufacturer_info);

   	  return view('admin_layout')
   	          ->with('admin.all_manufacturer', $manage_manufacturer);


   	  //return view('admin.all_category');
   }

   public function delete_manufacturer($manufacture_id)

   {
       DB::table('manufacture')
          ->where('manufacture_id', $manufacture_id)
          ->delete();

      Session::get('message', 'Manufacturer deleted successfully');
      return Redirect::to('/all-manufacturer');

      //return view('admin.add_category');
   }


   public function unactive_manufacturer($manufacture_id)

   {

   	  DB::table('manufacture')
   	      ->where('manufacture_id', $manufacture_id)
   	      ->update(['publication_status' => 0]);
   	  Session::put('message', 'Manufacturer Unactivated successfully');
   	      return Redirect::to('/all-manufacturer');


   	  //return view('admin.add_category');
   }

   public function active_manufacturer($manufacture_id)

   {

   	  DB::table('manufacture')
   	      ->where('manufacture_id', $manufacture_id)
   	      ->update(['publication_status' => 1]);
   	  Session::put('message', 'Manufacturer Activated Successfully');
   	      return Redirect::to('/all-manufacturer');

   }


    public function edit_manufacturer($manufacture_id)

   {
       $manufacturer_info = DB::table('manufacture')
                          ->where('manufacture_id', $manufacture_id)
                          ->first();

       $manufacturer_info = view('admin.edit_manufacturer')
   	          ->with('manufacturer_info', $manufacturer_info);

   	   return view('admin_layout')
   	          ->with('admin.edit_manufacturer', $manufacturer_info);

   	  //return view('admin.edit_category');
   }


   public function update_manufacturer(Request $request, $manufacture_id)
   {
      $data = array();
      $data['manufacture_name'] = $request->manufacture_name;
      $data['manufacture_description'] = $request->manufacture_description;

      DB::table('manufacture')
          ->where('manufacture_id', $manufacture_id)
          ->update($data);

          Session::get('message', 'Manufacturer successfully updated');
          return Redirect::to('/all-manufacturer');

   }

























}
